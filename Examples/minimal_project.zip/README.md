# Template example

This example can be used as a template to start a new project.

In its current state the project runs but the evolution does not follow any particular direction since the fitness function always returns 0. The fitness function needs to be updated to return something else than 0.
 
