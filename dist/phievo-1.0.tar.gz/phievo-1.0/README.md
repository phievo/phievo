# φ-evo

## Install phievo


Since _phievo_ is not pusblished on any offical repository yet, you need to install it manually. We wrote a make file that should run most of the commands for you. 

### install Anaconda
I you do not have python already installed on you computer, we recommand to install it via the [anaconda distribution](https://www.continuum.io/downloads).

Among other things, anaconda provides the standard package manager of python _pip_.

### install dependencies
	
```bash 
	make install_dependencies
```



### Known Errors
#### On Debian:

Debian may require the freetype and pg packages:

```bash
	# apt-get install libfreetype6-dev	
```
