__verbose__ = False
__silent__ = False
from phievo.StopEvolution import test_STOP_file,create_STOP_file
from phievo.launch_function import launch_evolution,test_project,clear_project
import phievo.AnalysisTools
from phievo.AnalysisTools.main_functions import read_network,download_example_seed
