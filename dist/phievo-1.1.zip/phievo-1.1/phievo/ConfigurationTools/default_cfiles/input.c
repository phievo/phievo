// An input is used to force the values of certain genes
// at specific times duric the simulation.
// More details:
// http://phievo.readthedocs.io/en/latest/create_new_project.html#input-c
// Examples of inputs can be found in the example projects:
// https://github.com/phievo/phievo/tree/master/Examples

void inputs(int pas,int ncell,int trial)
{
  // Example: Uncomment the following to set input for t>2.0
  // else input=1
  // int n_gene;
  // int input_index;
   
  // for (n_gene=0;n_gene<NINPUT;n_gene++)
  //   {
  //     input_index = trackin[n_gene];
  //     if(pas<2.0)
  //  	   {
  //	      history[input_index][pas][ncell] = 1.0;
  //       }
  //     else
  //       {
  //          history[input_index][pas][ncell] = 0.0;
  //       }
  //   }
}


