## Create a methylation interaction
from phievo import __silent__,__verbose__
if __verbose__:
    print("Execute Methyl (Interaction Template)")

from phievo.Networks import mutation
from phievo.Networks import deriv2
from phievo.Networks import classes_eds2
import copy



## Define the default dictionary_range
mutation.dictionary_ranges['Methyl.methyl'] = 0.0/(mutation.C*mutation.T)
mutation.dictionary_ranges['Methyl.demethyl'] = 0.0/mutation.T

def Methyl(classes_eds2.Interaction):
    """
    Methylation interaction

    Args:
        Methyl.methyl(float): binding rate of a methyl group
        Methyl.demethyl(float): unbinding rate of a methyl group
        label(str): Methylation
        input(list): Type of the inputs
        output(list): Type of the outputs
    """
    def __init__(self,methyl=0,demethyl=0):
        classes_eds2.Node.__init__(self)
        self.association=association
        self.disassociation=disassociation
        self.label='PP Interaction'
        self.input=['Complexable','Complexable']
        self.output=['Species']

    def __str__(self):
        """
        Used by the print function to display the interaction.
        """
        return "{0.id} Methylation: methyl. = {0.methyl:.2f}, demethyl = {0.demethyl:.2f}".format(self)

    def outputs_to_delete(self,net):
        """
        Returns the methylated form of the species to delete when the reaction is deleted.
        """
        return net.graph.successors(net)

    def number_Methyl(self):
        """
        Returns the number of possible methylation in the current network.
        """
        n = self.number_nodes('Methylable')
        n_Methyl = self.number_nodes('Methyl')
        return n-n_Methyl

    def new_Methyl(self,S,methyl,demethyl,types):
        """
        Creates a new :class:`Networks.Methyl.Methyl` and the species methylated for in the the network.

        Args:
            S: species to methylate
            methyl(float): binding rate of a methyl group
            demethyl(float): unbinding rate of a methyl group
            types(list): Types of the methylated species
        Returns:
            [Methyl,Methylated Species]
        """

        species_meth = classes_eds2.Species(types)
        meth_inter = Methyl(methyl,demethyl)
        if meth_inter.check_grammar([S],[species_meth]):
            self.add_Node(species_meth)
            self.add_Node(meth_inter)
            self.graph.add_edge(S,meth_inter)
            self.graph.add_edge(meth_inter,species_meth)
            return [meth_inter,species_meth]
        else:
            print("Error in grammar, new Methylation")
            return None

    def new_random_Methyl(self,S):
        """
        Creates a methylation with random parameters.
        
        Args:
            S: Species to methylate
        Returns:
            [methyl_inter,S_methyl]
        """
        types = [       
            ["Degradable",mutation.sample_dictionary_ranges('Species.degradation',self.Random)],
        ]
        # Check the type of S
        
        
    setattr(classes_eds2.Network,"number_Methyl",number_Methyl)
    setattr(classes_eds2.Network,"new_Methyl",new_Methyl)
    #setattr(classes_eds2.Network,"new_Methyl",new_Methyl)
    # def duplicate_Methyl(self,S,S_d,meth_inter,TM,TM_d):
    #     """
    #     Duplicate a Methylation
        
    #     Args:
    #         S: Original species
    #         S_d: New duplicated species
    #         meth_inter: Interaction to duplicate
    #         TM: Original TModule to duplicate
    #         TM_d: New duplicated TModule
    #     """
    #     # Copy the interaction and add it to the network
    #     meth_inter_d = copu.deepcopy(meth_inter)
    #     meth_inter_d.mutable = 1
    #     meth_inter_d.removable = 1
    #     self.add_Node(meth_inter_d)

    #     # Copy the Methylate species and add it to the Network
    #     S_meth = self.graph.successors(meth_inter)
    #     S_meth_d = copy.deepcopy(S_meth)
    #     S_meth_d.mutable = 1
    #     S_meth_d.removable = 1
    #     self.add_Node(S_meth_d)

    #     # Copy the Methylation
    #     self.add_edge(meth_inter_d,S_meth_d)
        
        
