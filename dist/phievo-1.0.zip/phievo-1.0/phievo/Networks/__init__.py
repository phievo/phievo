# Exist only to make Networks a package directory

from .mutation import Mutable_Network
from . import classes_eds2
from .classes_eds2 import Node,Species,TModule,Interaction
from . import interaction
from .interaction import *

