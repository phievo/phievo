/* Define geometry[NCELLTOT][NNEIGHBOR] array defining the neighbors of each cell
   Convention geometry < 0 ie invalid index -> no neighbor, ie used for end cells
   NB even for NCELLTOT=1, should have NNEIGHBOR == 3 to avoid odd seg faults since
   3 neighbors accessed in various loops, eventhough does nothing.
*/
   
void init_geometry();


